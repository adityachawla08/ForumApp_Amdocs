package org.example;

import java.sql.*;
import java.util.Scanner;

public class userManager {


    int register(Connection connection, Scanner scanner) {
        System.out.print("Enter your first name: ");
        String firstName = scanner.nextLine();
        System.out.print("Enter your last name: ");
        String lastName = scanner.nextLine();
        System.out.print("Enter your email: ");
        String email = scanner.nextLine();
        System.out.print("Create a password: ");
        String password = scanner.nextLine();

        try {
            // Insert into users table
            String registerUserSql = "INSERT INTO users (first_name, last_name, creation_date, is_active) VALUES (?, ?, ?, ?)";
            PreparedStatement registerUserStmt = connection.prepareStatement(registerUserSql, Statement.RETURN_GENERATED_KEYS);
            registerUserStmt.setString(1, firstName);
            registerUserStmt.setString(2, lastName);
            registerUserStmt.setDate(3, new java.sql.Date(System.currentTimeMillis())); // Current date
            registerUserStmt.setInt(4, 1); // Assuming new users are active
            registerUserStmt.executeUpdate();

            ResultSet generatedKeys = registerUserStmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                int userId = generatedKeys.getInt(1);

                // Insert into user_accounts table using the same userId
                String registerAccountSql = "INSERT INTO user_accounts (user_id, username, user_password, email) VALUES (?, ?, ?, ?)";
                PreparedStatement registerAccountStmt = connection.prepareStatement(registerAccountSql);
                String username = firstName + "_" + lastName;
                registerAccountStmt.setInt(1, userId);
                registerAccountStmt.setString(2, username);
                registerAccountStmt.setString(3, password);
                registerAccountStmt.setString(4, email);
                registerAccountStmt.executeUpdate();

                System.out.println("Registration successful! Your user ID is: " + userId);
                return userId;
            } else {
                System.out.println("Registration failed.");
                return -1;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }


    int login(Connection c,Scanner scanner) {
        System.out.print("Enter your username: ");
        String username = scanner.nextLine();

        System.out.print("Enter your password: ");
        String password = scanner.nextLine();

        try {
            String loginSql = "SELECT user_id FROM user_accounts WHERE username = ? AND user_password = ?";
            PreparedStatement loginStmt = c.prepareStatement(loginSql);
            loginStmt.setString(1, username);
            loginStmt.setString(2, password); // Hash the password for comparison
            ResultSet resultSet = loginStmt.executeQuery();

            if (resultSet.next()) {
                int userId = resultSet.getInt("user_id");
                System.out.println("Login successful!");
                return userId;
            } else {
                System.out.println("Login failed. Invalid username or password.");
                return -1;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }


}
