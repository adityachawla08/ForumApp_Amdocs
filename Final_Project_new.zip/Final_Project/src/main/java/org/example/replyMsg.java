package org.example;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class replyMsg {
    messaging rm =new messaging();
    public void replyToMessage(Connection connection, int userId, Scanner scanner) {
        try {
            System.out.println("***************REPLY********************");
            // Display available forums and prompt user to select one
            System.out.println("Available Forums:");
            rm.displayForums(connection);
            System.out.print("Enter the forum ID to view messages: ");
            int forumId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            // Display messages in the selected forum
            rm.displayMessagesInForum(connection, forumId);

            // Prompt user to select a message to reply to
            System.out.print("Enter the ID of the message you want to reply to: ");
            int parentMsgId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            // Collect reply message content
            System.out.println("Enter your reply:");
            String replyBody = scanner.nextLine();

            // Insert the reply message into the database
            String insertReplySql = "INSERT INTO new_message (msg_subject, msg_body, creator_id, creation_date, parent_msg_id, forum_id) " +
                    "VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement insertReplyStmt = connection.prepareStatement(insertReplySql);
            insertReplyStmt.setString(1, "Re: " + parentMsgId); // Modify the subject if needed
            insertReplyStmt.setString(2, replyBody);
            insertReplyStmt.setInt(3, userId);
            insertReplyStmt.setDate(4, new java.sql.Date(System.currentTimeMillis()));
            insertReplyStmt.setInt(5, parentMsgId); // Set the parent message ID
            insertReplyStmt.setInt(6, forumId); // Set the forum ID
            insertReplyStmt.executeUpdate();

            System.out.println("Reply posted successfully.");
            rm.displayMessagesInForum(connection,forumId);
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Failed to post the reply.");
        }
    }

}
