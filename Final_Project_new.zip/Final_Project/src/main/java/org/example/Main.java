package org.example;
import java.util.Scanner;
import java.sql.*;
public class Main {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        dbConnect d = new dbConnect();
        //Connection con = d.c;
        if(!d.open()){
            System.out.println("Cant open datasource");
        }
        else{
            System.out.println("Connected successfully");
        }


//        userManager um = new userManager();
//        //int userId= um.register(d.c,sc);
//        int login_id = um.login(d.c,sc);
//        if(login_id==-1){
//            System.exit(0);
//        }
//        int fid=1;
//        messaging msg = new messaging();
//        msg.postMessage(d.c,login_id,sc);
//        msg.displayMessagesInForum(d.c,fid);
//        replyMsg rmsg = new replyMsg();
//        rmsg.replyToMessage(d.c,login_id,sc);

        controlFlow cf = new controlFlow();
        cf.runApp(d.c);

        sc.close();
        try {
            d.c.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
