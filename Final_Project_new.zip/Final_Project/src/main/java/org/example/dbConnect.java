package org.example;
import java.sql.*;

public class dbConnect {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/forum_final";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "pass@word1";

    public Connection c;
    public boolean open(){
        try{
            c = DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);
            return true;
        }catch (SQLException e){
            System.out.println("Couldn't connect to database "+e.getMessage());
            return false;
        }
    }

    public void close(){
        try{
            if(c!=null){
                c.close();
            }
        }catch (SQLException e){
            System.out.println("Couldn't close connection "+e.getMessage());
        }
    }
}


 /*
        executing queries
         st.execute("query");

         printing query results

         st.execute("query");
         ResultSet rs = st.getResultSet();

         while(rs.next()){
            sout(rs.getString(column1) + rs.getInt(column2));

         }
         rs.close();

        ResultSet = st.executeQuery("query");

         */

